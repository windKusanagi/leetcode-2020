import { activeDescriptor } from '../active.descriptor';
import { Values, Field, FieldType } from '../../interfaces';
import { ConditionHow } from '../../interfaces/condition';



describe('active descriptor', () => {

  const fieldFixture: Field = {
    'name': 'hcpFirstName',
    'type': FieldType.TEXT,
    'label': 'form_field_firstName',
    'path': 'healthCareProfessional.person.contactInfo.firstName',
    'validations': {
      'max': 40
    }
  };

  const valuesFixture: Values = {
    hcpFirstName: 'adam',
    b: 'test@gmail.com',
    c: 'test@gmail.com',
    d: 'nottest@gmail.com',
    e: 'adam',
    f: '1963-11-22',
    g: false,
    h: undefined,
  };

  const typesFixture = {
    hcpFirstName: 'string',
    b: 'string',
    c: 'string',
    d: 'string',
    e: 'string',
    f: 'date',
    g: 'boolean',
    h: 'string',
  };

  it('should return the same descriptor if there are no conditions', () => {
    expect(activeDescriptor(fieldFixture, valuesFixture, typesFixture, null)).toBe(
      fieldFixture
    );
  });

  it('should throw an error if there is a condition without a then or otherwise', () => {
    const descriptor: Field = {
        ...fieldFixture,
      conditions: [{ when: { e: { is: 'adam' } } }],
    };
    expect(() =>
      activeDescriptor(descriptor, valuesFixture, typesFixture, null)
    ).toThrow();
  });

  it('should replace with then', () => {
    const descriptor: Field = {
      ...fieldFixture,
      conditions: [
        {
          when: { e: { is: 'adam' } },
          then: { hint: 'matched then!' },
          otherwise: { hint: 'matched otherwise!' },
        },
      ],
    };

    expect(activeDescriptor(descriptor, valuesFixture, typesFixture, null).hint).toBe(
      'matched then!'
    );
  });

  it('should replace with otherwise', () => {
    const descriptor: Field = {
      ...fieldFixture,
      conditions: [
        {
          when: { e: { is: 'fred' } },
          then: { hint: 'matched then!' },
          otherwise: { hint: 'matched otherwise!' },
        },
      ],
    };

    expect(activeDescriptor(descriptor, valuesFixture, typesFixture, null).hint).toBe(
      'matched otherwise!'
    );
  });

  it('should return the same reference if the last descriptor is the same', () => {
    const descriptor: Field = {
      ...fieldFixture,
      conditions: [
        {
          when: { e: { is: 'fred' } },
          then: { hint: 'matched then!' },
          otherwise: { hint: 'matched otherwise!' },
        },
      ],
    };

    const lastDescriptor = activeDescriptor(
      descriptor,
      valuesFixture,
      typesFixture,
      null
    );

    expect(
      activeDescriptor(
        descriptor,
        valuesFixture,
        typesFixture,
        null,
        lastDescriptor
      )
    ).toBe(lastDescriptor);
  });

  it('should allow nested conditions', () => {
    const descriptor: Field = {
      ...fieldFixture,
      conditions: [
        {
          when: { e: { is: 'adam' } },
          then: {
            hint: 'matched then!',
            conditions: [
              {
                when: {
                  f: { before: '100 years ago' },
                },
                then: {
                  hint: 'matched nested then!',
                },
                otherwise: {
                  hint: 'matched nested otherwise!',
                },
              },
            ],
          },
        },
      ],
    };

    expect(activeDescriptor(descriptor, valuesFixture, typesFixture, null).hint).toBe(
      'matched nested otherwise!'
    );
  });

  it('should not transform the name property', () => {
    const descriptor: Field = {
      ...fieldFixture,
      name: 'some name',
      conditions: [
        {
          when: { e: { is: 'adam' } },
          then: { name: 'new name' },
          otherwise: { hint: 'matched otherwise!' },
        },
      ],
    };

    expect(activeDescriptor(descriptor, valuesFixture, typesFixture, null).name).toBe(
      'some name'
    );
  });

  it('should not transform the type property', () => {
    const descriptor: Field = {
      ...fieldFixture,
      conditions: [
        {
          when: { e: { is: 'adam' } },
          then: { type: FieldType.DATE },
          otherwise: { hint: 'matched otherwise!' },
        },
      ],
    };

    expect(activeDescriptor(descriptor, valuesFixture, typesFixture, null).type).toBe(
      fieldFixture.type
    );
  });
});
