import { FieldCastTransformType } from '../interfaces/transform';
import { FieldTransformType, FieldTransform } from '../interfaces';
import { parseISO } from 'date-fns';

const canTransform = (fn: (v: any) => string) => (v: any) => v === null || typeof v === 'undefined' ? v : fn(v);
const combineTransformers = (...transformers: TransformFn[]): TransformFn => canTransform(v =>
  transformers.reduce((acc, t) => t(acc), v));

export type TransformFn = (v: string) => any;

const uppercase: TransformFn = v => v.toString().toUpperCase();
const lowercase: TransformFn = v => v.toString().toLowerCase();
const alpha: TransformFn = v => v.toString().replace(/[^A-z]/g, '');
const numeric: TransformFn = v => v.toString().replace(/[^\d]/g, '');
const alphanumeric: TransformFn = v => v.toString().replace(/[^A-z0-9]/g, '');
const extendedAlpha: TransformFn = v => v.toString().replace(/[^A-zÀ-ÿ]/g, '');
const extendedAlphanumeric: TransformFn = v => v.toString().replace(/[^A-zÀ-ÿ0-9]/g, '');
const trim: TransformFn = v => v.toString().trim();
const strip: TransformFn = v => v.toString().replace(/\s/g, '');
const length = (what: number): TransformFn => v => v.toString().substring(0, what);
const only = (what: string): TransformFn => v => v.toString().replace(new RegExp(`[^${what}]`, 'g'), '');
const not = (what: string): TransformFn => v => v.toString().replace(new RegExp(`[${what}]`, 'g'), '');
const cast = (to: string): TransformFn => (v: any) => {
  switch (to) {
    case FieldCastTransformType.DATE: return (v instanceof Date) ? v : parseISO(v);
    case FieldCastTransformType.NUMBER: return +v;
    case FieldCastTransformType.BOOLEAN: return !!v;
    case FieldCastTransformType.STRING:
    default: return v + '';
  }
};

const postal: TransformFn = combineTransformers(
  alphanumeric,
  strip,
  uppercase,
  length(6)
);

const TransformFn = {
  [FieldTransformType.UPPERCASE]: uppercase,
  [FieldTransformType.POSTAL]: postal,
  [FieldTransformType.LOWERCASE]: lowercase,
  [FieldTransformType.ALPHA]: alpha,
  [FieldTransformType.NUMERIC]: numeric,
  [FieldTransformType.ALPHANUMERIC]: alphanumeric,
  [FieldTransformType.EXTENDED_ALPHANUMERIC]: extendedAlphanumeric,
  [FieldTransformType.EXTENDED_ALPHA]: extendedAlpha,
  [FieldTransformType.TRIM]: trim,
  [FieldTransformType.STRIP]: strip
};

export const createTransformer = (transform: FieldTransform) =>
  combineTransformers(
    ...(Array.isArray(transform)
      ? transform
      : transform
      ? [transform]
      : []
    ).map((t: FieldTransformType) => {

      if (t[FieldTransformType.CAST]) {
        return cast(t[FieldTransformType.CAST]);
      }

      if (t[FieldTransformType.ONLY]) {
        return only(t[FieldTransformType.ONLY]);
      }

      if (t[FieldTransformType.NOT]) {
        return not(t[FieldTransformType.NOT]);
      }

      if (t.hasOwnProperty(FieldTransformType.LENGTH)) {
        return length(t[FieldTransformType.LENGTH]);
      }

      if (!TransformFn[t]) {
        throw new Error(`No transformer found for ${t}`);
      }
      return TransformFn[t];
    })
  );
