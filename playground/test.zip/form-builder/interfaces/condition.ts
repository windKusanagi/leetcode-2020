import { SchemaValidator } from './schema.validator';
export type When = SchemaValidator | SchemaValidator[];

export enum ConditionHow {
  EVERY = 'every',
  SOME = 'some'
}

export interface Condition {
  when: When;
  how?: ConditionHow;
}
