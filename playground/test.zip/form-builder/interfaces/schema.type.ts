export enum SchemaType {
  STRING = 'string',
  ARRAY = 'array',
  BOOLEAN = 'boolean',
  DATE = 'date',
  OBJECT = 'object',
  NUMBER = 'number'
}
