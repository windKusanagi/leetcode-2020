import { createTransformer } from '../transform';
import { FieldTransformType } from '../../interfaces';

describe('transform', () => {
  it('should transform uppercase', () => {
    expect(createTransformer(FieldTransformType.UPPERCASE)('adam')).toBe(
      'ADAM'
    );
  });

  it('should transform lowercase', () => {
    expect(createTransformer(FieldTransformType.LOWERCASE)('ADAM')).toBe(
      'adam'
    );
  });

  it('should transform numeric', () => {
    expect(createTransformer(FieldTransformType.NUMERIC)('AD9302AM')).toBe(
      '9302'
    );
  });

  it('should transform alpha', () => {
    expect(createTransformer(FieldTransformType.ALPHA)('AD9302AM')).toBe(
      'ADAM'
    );
  });

  it('should transform alphanumeric', () => {
    expect(
      createTransformer(FieldTransformType.ALPHANUMERIC)('AD93?È.()02AM')
    ).toBe('AD9302AM');
  });

  it('should transform extended alphanumeric', () => {
    expect(
      createTransformer(FieldTransformType.EXTENDED_ALPHANUMERIC)(
        'AD93?È.()02AM'
      )
    ).toBe('AD93È02AM');
  });

  it('should trim', () =>
    expect(
      createTransformer(FieldTransformType.TRIM)(' white space on both ends ')
    ).toBe('white space on both ends'));

  it('should strip', () => {
    expect(
      createTransformer(FieldTransformType.STRIP)(' white space on both ends ')
    ).toBe('whitespaceonbothends');
  });

  it('should only allow certain characters', () => {
    expect(
      createTransformer({[FieldTransformType.ONLY]: 'CRZig'})(
        'this string is CRAZY!'
      )
    ).toBe('iigiCRZ');
  });

  it('should perform a postal transform - no whitespace, 6 alphanumeric characters, uppercase', () =>
    expect(createTransformer(FieldTransformType.POSTAL)('a0a)  4J0 ')).toBe(
      'A0A4J0'
    ));

  it('should not allow certain characters', () => {
    expect(
      createTransformer({ [FieldTransformType.NOT]: 'CRZig' })(
        'this string is CRAZY!'
      )
    ).toBe('ths strn s AY!');
  });

  it('should restrict length', () =>
    expect(
      createTransformer({ [FieldTransformType.LENGTH]: 10 })(
        'should be no longer than 10 characters'
      )
    ).toBe('should be '));

  it('should create a transformer', () => {
    expect(createTransformer(FieldTransformType.UPPERCASE)('adam')).toBe(
      'ADAM'
    );
  });

  it('should create a transformer from an array', () => {
    expect(
      createTransformer([
        FieldTransformType.UPPERCASE,
        FieldTransformType.TRIM,
      ])(' ad am ')
    ).toBe('AD AM');
  });

  it('should throw an error if an unknown transformer is given', () =>
    // @ts-ignore
    expect(() => createTransformer('unknown')('ADAM')).toThrow());
});
