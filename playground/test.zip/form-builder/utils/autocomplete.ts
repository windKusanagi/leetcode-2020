import { tmpl } from './tmpl';
import { getter } from 'property-expr';
import { fieldOptions } from './select.options';
import { Field } from '../interfaces';
import { AutoCompleteService } from 'modules/formbuilder/services/autocomplete.service';

const accessItem = (item: any, accessor?: string): string => accessor ? getter(accessor, true)(item || {}) : item;
const DEFAULT_EMPTY_TEXT = v => `No results for ${v}`;
const DEFAULT_LOADING_TEXT = v => `Searching for ${v}...`;

export const autocomplete = (field: Field) => {
  const async = field.url ? (value: string, autoCompleteService: AutoCompleteService) => field.urlParams
      ? autoCompleteService.fetchSearchResults(field.url, { [field.urlParams] : value})
      : autoCompleteService.fetchSearchResults(tmpl(field.url, { value }))
    : undefined;
  // if this has static options....
  const hasStaticOptions = field.hasOwnProperty('options') && field.options.length;
  const options = hasStaticOptions ? fieldOptions(field) : [];
  const display = hasStaticOptions ? 'label' : field.display;
  const filterAccessor = field.filterAccessor || (hasStaticOptions ? 'label' : '') || field.optionAccessor;
  const sortAccessor = field.sortAccessor || (hasStaticOptions ? 'value' : '') || field.optionAccessor;
  const displayFn = (item: any): string => accessItem(item, display);

  const filterFn = (query: string, item: any) => accessItem(
    item,
    filterAccessor
  ).toString().toLowerCase().match(query.toLowerCase());

  const sort = (itemA: any, itemB: any) =>
    accessItem(
      itemA,
      sortAccessor
    ).toString().localeCompare(
      accessItem(
        itemB,
        sortAccessor
      ).toString(),
      undefined,
      {
        numeric: true,
        sensitivity: 'base'
      }
    ) * (field.sortOrder === 'asc' ? 1 : -1);

  const onSelect = (item: any) => item ? accessItem(hasStaticOptions ? item.value : item, field.optionAccessor) : item;

  return {
    async,
    displayFn,
    emptyText: field.emptyText ? v => `${field.emptyText} ${v}` : DEFAULT_EMPTY_TEXT,
    loadingText: field.loadingText ? v => `${field.loadingText} ${v}` : DEFAULT_LOADING_TEXT,
    filterFn,
    options,
    sort: field.hasOwnProperty('sortAccessor') || field.hasOwnProperty('sortOrder') ? sort : undefined,
    onSelect,
  };
};
