import { getter } from 'property-expr';

// very simple templater based on tiny-tim
// https://github.com/premasagar/tim/blob/master/tinytim.js
// tmpl("some string {{var.path}}",{var: path: { 'some value' })
export const tmpl = (what = '', props = {}) => what.replace(
  new RegExp(`{{\\s*([a-z0-9_][\\.a-z0-9_]*)\\s*}}`, 'gi'),
  (_, token) => getter(token)(props)
);
