import { Field, FormFieldErrors } from '../interfaces';

export const showErrors = (field: Field, hasErrors: boolean, touched: boolean, dirty: boolean, isSubmitted: boolean) => {

  const how = field.behavior.when;
  const showSubmitted = field.behavior.submitted && isSubmitted;

  if (!hasErrors || how ===  FormFieldErrors.NONE || field.disabled || field.readOnly) {
    return false;
  }

  switch (how) {
    case FormFieldErrors.TOUCHED: return touched || showSubmitted;
    case FormFieldErrors.DIRTY: return dirty || showSubmitted;
    case FormFieldErrors.ALWAYS: return true;
    default: return false;
  }
};
