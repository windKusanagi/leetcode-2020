export enum FieldTransformType {
  UPPERCASE = 'uppercase',
  LOWERCASE = 'lowercase',
  ALPHA = 'alpha',
  NUMERIC = 'numeric',
  ALPHANUMERIC = 'alphanumeric',
  EXTENDED_ALPHANUMERIC = 'extended_alphanumeric',
  EXTENDED_ALPHA = 'extended_alpha',
  TRIM = 'trim',
  STRIP = 'strip',
  POSTAL = 'postal',
  ONLY = 'only',
  NOT = 'not',
  LENGTH = 'maxLength',
  CAST = 'cast'
}

export enum FieldCastTransformType {
  STRING = 'string',
  NUMBER = 'number',
  BOOLEAN = 'boolean',
  DATE = 'date',
}

interface LengthTransformer {
  [FieldTransformType.LENGTH]: number;
}

interface OnlyTransformer {
  [FieldTransformType.ONLY]: string;
}

interface NotTransformer {
  [FieldTransformType.NOT]: string;
}

interface CastTransformer {
  [FieldTransformType.CAST]: FieldCastTransformType;
}

type Transform = FieldTransformType | LengthTransformer | OnlyTransformer | NotTransformer | CastTransformer;
export type FieldTransform = Transform | Transform[];
