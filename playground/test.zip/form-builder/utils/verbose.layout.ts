import { FlexGrid, VerboseFlexGrid } from '../interfaces';

export const FIELD_LAYOUT_DEFAULTS: VerboseFlexGrid = {
  cols: 4,
  grow: 1,
  shrink: 0,
  spacing: 3
};

export const FIELD_LAYOUT_COLUMNS = 12;

export const verboseLayout = (layout: FlexGrid = {}, defaults: Partial<VerboseFlexGrid> = FIELD_LAYOUT_DEFAULTS): VerboseFlexGrid => {

  const useDefaults = {
    ...FIELD_LAYOUT_DEFAULTS,
    ...defaults
  };

  if (typeof layout === 'number' || layout === 'auto') {
    return {
      ...useDefaults,
      cols: <VerboseFlexGrid['cols']>layout,
    };
  }

  return {
    ...useDefaults,
    ...layout
  };

};
