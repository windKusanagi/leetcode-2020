import { Field, FormErrorProperties, FieldAppearance, FormFieldErrors } from './field';
import { FieldGridLayout, VerboseFlexGrid } from './layout';
import { Values } from './values';

export interface FieldsConfiguration {
  [key: string]: Field;
}

export interface FormBuilderField extends Field {
  id?: string;
  layout?: FieldGridLayout;
}

export interface FormBuilderConfig {
  fields?: FormBuilderField[];
  initialValues?: Values;
  behavior?: FormErrorProperties;
  appearance?: FieldAppearance;
  spacing?: VerboseFlexGrid['spacing'];
}

export const DEFAULT_BEHAVIOR: FormBuilderConfig['behavior'] = {
  when: FormFieldErrors.TOUCHED,
  submitted: true,
  numErrors: 1 // only show 1 error at a time
};

export const DEFAULT_APPEARANCE: FormBuilderConfig['appearance'] = {
  style: 'standard',
  floatLabel: 'always'
};

export enum FormStatus {
  VALID = 'valid',
  INVALID = 'invalid',
  PENDING = 'pending'
}
