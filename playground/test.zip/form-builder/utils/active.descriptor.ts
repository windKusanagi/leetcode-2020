import { Field } from '../interfaces';
import { matches, createSchemas } from '@sti/validation-schema';

export const activeDescriptor = (descriptor: Field, values: any, types: any, parentSchema: any, lastDescriptor?: Field): Field => {

  if (!descriptor.conditions || !descriptor.conditions.length) {
    return descriptor;
  }

  const nextDescriptor = descriptor.conditions.reduce(
    (acc, condition, idx) => {
      const { how, then, otherwise, when } = condition;

      if (!then && !otherwise) {
        throw new Error(
          'One of a then or otherwise must be defined in a form condition'
        );
      }

      const doesMatch = matches(
        { how, schemas: createSchemas(when, types, parentSchema) },
        values
      );

      const which = doesMatch ? then : otherwise;

      if (!which) {
        return { ...acc, conditions: null };
      }

      return {
        ...acc,
        conditions: null,
        ...which,
        // comparing keys for fields of the same name allows us to
        // determine if we need to replace a descriptor in our
        // ConfiguredFormContext with another one
        conditionKey: `${acc.conditionKey || ''}${idx}${
          doesMatch ? 'then' : 'otherwise'
        }`,
        validations: {
          ...(acc.validations || {}),
          ...(which.validations || {}),
        },
        // these properties are immutable
        type: acc.type,
        name: acc.name,
        path: acc.path,
      };
    },
    descriptor
  );

  if (!nextDescriptor.conditions) {
    return lastDescriptor && nextDescriptor.conditionKey === lastDescriptor.conditionKey ? lastDescriptor : nextDescriptor;
  }

  return activeDescriptor(nextDescriptor, values, types, parentSchema, lastDescriptor);
};
