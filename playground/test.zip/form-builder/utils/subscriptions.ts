import { Field, Condition } from '../interfaces';

export const conditionSubscriptions = (condition: Condition) =>
  (Array.isArray(condition.when) ? condition.when : [condition.when]).reduce((acc, schemaValidator) =>
    acc.concat(Object.keys(schemaValidator)), []);

export const fieldSubscriptions = (field: Field) =>
  (field.conditions || []).reduce((acc, condition) =>
    acc.concat(conditionSubscriptions(condition)), []);

export const fieldsSubscriptions = (fields: Field[]) =>
  fields.reduce((acc, field) => acc.concat(fieldSubscriptions(field)), []);
