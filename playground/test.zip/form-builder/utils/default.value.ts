import { Field, FieldType } from '../interfaces';
import { normalizerForField } from './setup.field';

export const defaultValueForFieldType = (
  type: FieldType,
  field: Field = undefined
) => {
  switch (type) {
    case FieldType.CHECKBOX:
      return field && typeof field.off !== 'undefined' ? field.off : false;
    case FieldType.NUMBER:
    case FieldType.DATE:
      return undefined;
    default:
      return '';
  }
};

export const defaultValueForField = (field: Field, defaultValue: any) => {
  const val =
    typeof field.value !== 'undefined'
      ? field.value
      : typeof defaultValue !== 'undefined'
      ? defaultValue
      : field.default;

  return normalizerForField(field)(
    typeof val !== 'undefined'
      ? val
      : defaultValueForFieldType(field.type, field)
  );
};
