import { createSchemas, from, matches, schemaDependencies, to } from '@sti/validation-schema';
import { get, isEmpty, isEqual } from 'lodash';
import { BehaviorSubject, combineLatest, Observable, of, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, filter, map, pairwise, shareReplay, startWith, switchMap, takeUntil, tap } from 'rxjs/operators';
import {
  Condition,
  DEFAULT_APPEARANCE,
  DEFAULT_BEHAVIOR,
  Field,
  FieldDescriptorMap,
  FieldState,
  FormBuilderConfig,
  FormStatus,
  GlobalFormCondition,
  Modification,
  Option,
  Ref,
  SchemaType,
  Values,
  When,
  FormModifier,
} from './interfaces';
import { SchemaValidationErrors } from './interfaces/validation.error';
import {
  activeDescriptor,
  conditionSubscriptions,
  createFormValidationSchema,
  defaultValueForField,
  fieldSubscriptions,
  schemaForType,
  setupField,
  showErrors,
} from './utils';
import { validateField } from './utils/validator';
import { FIELD_LAYOUT_DEFAULTS } from './utils/verbose.layout';

export class FormBuilder {

  private static CONTEXT_PREFIX = '#';

  private static _isContextKey(key: string) {
    return key[0] === FormBuilder.CONTEXT_PREFIX;
  }

  private static _makeContextKey(key: string) {
    return `${FormBuilder.CONTEXT_PREFIX}${key}`;
  }

  private _values$ = new BehaviorSubject<Values>({});
  private _touched$ = new BehaviorSubject<{ [key: string]: boolean }>({});
  private _validationSchema$ = new BehaviorSubject(null);
  private _status$ = new BehaviorSubject(FormStatus.VALID);
  private _types$ = new BehaviorSubject<{ [key: string]: SchemaType }>({});
  private _submitting$ = new BehaviorSubject(false);
  private _submitCount$ = new BehaviorSubject(0);
  private _initialValues$ = new BehaviorSubject<Values>({});
  private _defaults$ = new BehaviorSubject<Values>({});
  private _disabled$ = new BehaviorSubject<{ [key: string]: boolean }>({});
  private _batching$ = new BehaviorSubject(false);
  private _batchDepth = 0;
  private _registeredDescriptors$ = new BehaviorSubject<FieldDescriptorMap>({});
  private _activeDescriptors$ = new BehaviorSubject<FieldDescriptorMap>({});
  private _context$ = new BehaviorSubject<Values>({});
  private _lookups: { [key: string]: Modification } = {};

  private _validating$ = new BehaviorSubject<{ [key: string]: boolean }>({});
  private _fieldErrors$ = new BehaviorSubject<{ [key: string]: SchemaValidationErrors }>({});
  private _lastValidatedValues = {};
  private _lastValidatedSchemas = {};
  private _needsValidating = false;

  // activeValidations has been created because creation of the next validationSchema
  // is debounced from the updating of an activeDescriptor.
  // if we compare the _lastValidatedSchemas of a field to those of it's activeDescriptor
  // we can enter a race condition where _lastValidatedSchemas[field] === activeDescriptor[field].validations !== validationSchemas.fields[field]
  // _activeValidations needs to be set AFTER the debounce in the computation of the next validation schema
  private _activeValidations = {};

  private _fieldStates: { [key: string]: Observable<FieldState> } = {};
  private _descriptorAndFieldStates: { [key: string]: Observable<{ descriptor: Field, state: FieldState }> } = {};

  // external modifications to the form via conditions/modifications
  private _formConditions = new Map<GlobalFormCondition, () => void>();
  private _modifications$ = new BehaviorSubject<Map<Modification, { where?: When }>>(new Map());

  // unwrapped initialValues - computed as needed
  private _transformedInitialValues = {};

  // undo conditional things that need to be undone
  private _restore: Map<any, () => void> = new Map();

  private _modified: Set<string> = new Set();

  public appearance?: FormBuilderConfig['appearance'] = DEFAULT_APPEARANCE;
  public behavior?: FormBuilderConfig['behavior'] = DEFAULT_BEHAVIOR;
  public spacing?: FormBuilderConfig['spacing'] = FIELD_LAYOUT_DEFAULTS.spacing;

  public onSubmit: (v: Values) => void;
  public onSubmitError: (v: Values) => void;
  public onReset: () => void;

  protected set _initialValues(initial: Values) {
    this._initialValues$.next(initial);
  }

  public get context() {
    return this._context$.value;
  }

  public get context$() {
    return this._context$.asObservable();
  }

  public get submitting() {
    return this._submitting$.value;
  }

  public get submitting$() {
    return this._submitting$.asObservable();
  }

  public get submitCount() {
    return this._submitCount$.value;
  }

  public get submitCount$() {
    return this._submitCount$.asObservable();
  }

  public get values() {
    return this._values$.value;
  }

  public get values$() {
    return this._values$.asObservable();
  }

  public get transformedValues() {
    return this._out(this.values);
  }

  public get errors$() {
    return this._fieldErrors$.asObservable();
  }

  public get errors() {
    return this._fieldErrors$.value;
  }

  public get validating$() {
    return this._validating$.asObservable();
  }

  public get validating() {
    return this._validating$.value;
  }

  public transformedValues$ = this._subscribeToThing(this.activeDescriptors$).pipe(
    switchMap(() => this._subscribeToThing(this.values$)),
    map(v => this._out(v)),
    shareReplay({ refCount: true, bufferSize: 1 }),
  );

  public required$ = this._subscribeToThing(this.activeDescriptors$)
    .pipe(map(a => Object.keys(a).some(key => a[key].required)));

  public valid$ = this.status$.pipe(
    filter(v => v !== FormStatus.PENDING),
    map(v => v === FormStatus.VALID),
    distinctUntilChanged(),
  );

  public get valid() {
    return this._status$.value === FormStatus.VALID;
  }

  public get pending() {
    return this._status$.value === FormStatus.PENDING;
  }

  public get invalid() {
    return this._status$.value === FormStatus.INVALID;
  }

  public dirty$ = this._subscribeToThing(this.values$).pipe(
    switchMap(() => this._subscribeToThings(...Object.keys(this._fieldStates).map(k => this._fieldStates[k]))),
    map(([...args]) => args.some(f => f.dirty && !f.disabled)),
    distinctUntilChanged(),
  );

  public inErrorState$ = this._subscribeToThing(this.activeDescriptors$).pipe(switchMap(a => this._checkFields(Object.keys(a).map(key => a[key]), this.fieldInErrorState.bind(this))));

  public get touched() {
    return this._touched$.value;
  }

  public get touched$() {
    return this._touched$.asObservable();
  }

  public get validationSchema() {
    return this._validationSchema$.value;
  }

  public get validationSchema$() {
    return this._validationSchema$.asObservable();
  }

  public get status() {
    return this._status$.value;
  }

  public get status$() {
    return this._status$.asObservable();
  }

  public get types() {
    return this._types$.value;
  }

  public get types$() {
    return this._types$.asObservable();
  }

  public get initialValues() {
    return this._initialValues$.value;
  }

  public get initialValues$() {
    return this._initialValues$.asObservable();
  }

  public get modifications() {
    return this._modifications$.value;
  }

  public get modifications$() {
    return this._modifications$.asObservable();
  }

  public get defaults() {
    return this._defaults$.value;
  }

  public get defaults$() {
    return this._defaults$.asObservable();
  }

  public get disabled() {
    return this._disabled$.value;
  }

  public get disabled$() {
    return this._disabled$.asObservable();
  }

  public get registeredDescriptors() {
    return this._registeredDescriptors$.value;
  }

  public get registeredDescriptors$() {
    return this._registeredDescriptors$.asObservable();
  }

  public get activeDescriptors() {
    return this._activeDescriptors$.value;
  }

  public get activeDescriptors$() {
    return this._activeDescriptors$.asObservable();
  }


  constructor() {
    // update the validation schema when necessary
    this._subscribeToThing(this.activeDescriptors$)
      .pipe(
        debounceTime(0),
        map(actives => Object.keys(actives).reduce((acc, key) => ({ ...acc, [key]: actives[key].validations }), {})),
        startWith({}),
        pairwise(),
        // shallow
        filter(([last, next]) => Object.keys(last).length !== Object.keys(next).length || Object.keys(last).some(key => !next.hasOwnProperty(key) || last[key] !== next[key])),
        tap(what => (this._activeValidations = what[1])),
        map(() => Object.keys(this.activeDescriptors).reduce((acc, key) => acc.concat(this.activeDescriptors[key]), [])),
      ).subscribe(fields => this._validationSchema$.next(createFormValidationSchema(fields)));

    this._subscribeToThings(
      this.values$,
      this.validationSchema$,
    )
      .pipe(tap(() => this._needsValidating = true))
      .subscribe(() => this.validate());

  }

  public async submit() {
    this._submitting$.next(true);
    await this.validate();

    // increase the submit count
    this._submitCount$.next(this.submitCount + 1);

    // only call onSubmit if the form is valid
    if (this._isFormValid()) {

      try {
        if (this.onSubmit) { await this.onSubmit(this.transformedValues); }
      } catch (err) {
        if (this.onSubmitError) { this.onSubmitError(this.values); }
      }
    }

    this._submitting$.next(false);
  }

  public setLookup(lookupId: string, options: Option[]) {
    if (!this._lookups[lookupId]) {
      const modification = { options };
      this._lookups[lookupId] = modification;
    }
    return this._applyLookup(lookupId);
  }

  public addFormConditions(conditions: GlobalFormCondition[]) {
    return this.batch(() => conditions.reduce((acc, c) => {
      const undo = this.addFormCondition(c);
      // return a single undo function
      return () => { this.batch(() => { acc(), undo(); }); };
    }, () => { }));
  }

  public addFormCondition(condition: GlobalFormCondition) {
    if (this._formConditions.has(condition)) {
      return this._formConditions.get(condition);
    }

    const { where } = condition;
    const s = new Subject();

    this
      .matches(condition)
      .pipe(
        takeUntil(s),
        distinctUntilChanged(),
        map(b => b ? condition.then : condition.otherwise),
      )
      .subscribe(what => {
        this._doRestore(condition);
        if (what) { this._restore.set(condition, this.modify(what, { where })); }
      });

    const undo = () => {
      this._doRestore(condition);
      s.next(), s.complete();
    };

    // return a function to unregister this condition
    this._formConditions.set(condition, undo);
    return undo;
  }

  public modify(modification: Modification, { where }: { where?: When }) {
    const modificationMap = this._modifications$.value;
    const undo = () => this._unmodify(modification);
    this.batch(() => !this.modifications.has(modification) && this._modifications$.next(modificationMap.set(modification, { where })));
    return undo;
  }

  public addModifiers(...modifiers: FormModifier[]) {
    return this.batch(() => {
      const undos = modifiers.map(({ where, ...modifier }) => {
        return this.modify(modifier, { where });
      });
      return () => this.batch(() => undos.forEach(u => u()));
    });
  }

  private _fieldsToValidate() {
    return Object.keys(this.values).reduce((acc, fieldName) => {
      // values can be updated before an activeDescriptor
      // is present when a field is registered, skip this for now
      // if the newly registered field has validations then this
      // will be called again when the activeDescriptor exists
      if (!this.activeDescriptors[fieldName]) { return acc; }
      const sameValue = this.values[fieldName] === this._lastValidatedValues[fieldName];
      const sameSchema = this._activeValidations[fieldName] === this._lastValidatedSchemas[fieldName];
      const sameDependencies = schemaDependencies(this._activeValidations[fieldName]).every(dep => this.values[dep] === this._lastValidatedValues[dep]);
      return sameValue && sameSchema && sameDependencies ? acc : acc.concat(fieldName);
    }, []);
  }

  private _isFormValid() {
    return Object.keys(this.errors).every(key => !this.errors[key]);
  }

  public async validate() {
    if (!this.validationSchema) {
      return;
    }

    if (this._needsValidating) {
      this._needsValidating = false;
    }

    this._status$.next(FormStatus.PENDING);

    await Promise.all(this._fieldsToValidate().map(async field => {
      this._validating$.next({ ...this.validating, [field]: true });
      const fieldErrors = await validateField(field, this.validationSchema, this.values);
      if (this._needsValidating) { return; }
      this._validating$.next({ ...this.validating, [field]: false });
      this._fieldErrors$.next({ ...this.errors, [field]: fieldErrors });
      this._lastValidatedValues[field] = this.values[field];
      this._lastValidatedSchemas[field] = this._activeValidations[field];
    }));

    if (this._needsValidating) {
      return this.validate();
    }

    this._status$.next(this._isFormValid() ? FormStatus.VALID : FormStatus.INVALID);

    // set all the lastValidated values so that dependency checking will work
    this._lastValidatedValues = this.values;

  }

  public batch<T>(fn: () => T): T {
    this._batchDepth++;
    this._batching$.next(true);
    const r = fn();
    this._batchDepth--;
    if (!this._batchDepth) {
      this._batching$.next(false);
    }
    return r;
  }

  public reset(values: Values) {
    this.batch(() => {

      this._formConditions.clear();

      // remove existing modifications
      this._modifications$.next(new Map());

      // reapply lookup modifications
      Object.keys(this._lookups).forEach(lookupId => this._applyLookup(lookupId));

      this.clearContext();

      if (values) {
        this._transformedInitialValues = {};
        this._initialValues$.next(values);
      }

      this._modified.clear();
      this._restore.clear();

      this._values$.next(Object.keys(this.registeredDescriptors).reduce((acc, key) => ({
        ...acc,
        [key]: this._initialValueForField(this.registeredDescriptors[key]),
      }), {}));
      this._touched$.next({});
      this._submitCount$.next(0);
    });
  }

  public resetValues() {
    this._values$.next(Object.keys(this.registeredDescriptors).reduce((acc, key) => ({
      ...acc,
      [key]: this._initialValueForField(this.registeredDescriptors[key]),
    }), {}));
    this._touched$.next({});
    this._submitCount$.next(0);
  }

  public registerFieldDescriptors(fields: Field[]) {
    return combineLatest(...this.batch(() => fields.map(f => this.registerFieldDescriptor(f))));
  }

  public unregisterFieldDescriptors(fields: Field[]) {
    this.batch(() => fields.map(f => this.unregisterFieldDescriptor(f)));
  }

  public registerFieldDescriptor(field: Field): Observable<{ descriptor: Field, state: FieldState }> {
    const id = this._fieldDescriptorIdentifier(field);

    // if this is the first time this descriptor has been registered...
    if (!this.registeredDescriptors[id]) {


      // add it to registered descriptors
      this._registeredDescriptors$.next({
        ...this.registeredDescriptors,
        [id]: {
          id,
          appearance: this.appearance,
          behavior: this.behavior,
          spacing: this.spacing,
          ...field,
        },
      });

      // if the field hasn't been registered yet
      if (!this.types[field.name]) {
        this._types$.next({ ...this.types, [field.name]: schemaForType(field.type) });
        this._values$.next({ ...this.values, [field.name]: this._initialValueForField(field) });
      }

      // start by listening for any external modifications
      this._subscribeToThing(this.modifications$)
        .pipe(
          map(() => this._modificationsForField(this.registeredDescriptors[id])),
          distinctUntilChanged(isEqual),
          map(modded => ({ ...this.registeredDescriptors[id], ...modded })),

          // whenever a new global modification happens
          // we need to force a new descriptor by bypassing the check on conditionKey
          // this is one way to do it
          tap(() => this.activeDescriptors[id] && (this.activeDescriptors[id].conditionKey = 'RESET')),
          switchMap(descriptor => {

            // setup the subscriptions to the fields that will change this field descriptor by inspecting it's conditions
            // Note: there is an important caveat here. Any field whose value may change this descriptor MUST be a key in it's
            // "when" field condition right now.
            // This means that this kind of condition:
            // {
            //    "when": { "field1": { "same": "field2" } },
            //    "then": ...updates
            // }
            // WILL NOT update this descriptor if the value of "field2" changes and causes the schema to fail
            // this is for performance reasons (we may be able to remove this restriction later if we can make this fast enough)
            // so right now the above condition will have to look like this:
            // {
            //    "when": { "field1": { "same": "field2" }, "field2": { "same": "field1" } },
            //    "then": updates
            // }
            return this._subscribeToValues(...fieldSubscriptions(descriptor))
              .pipe(
                debounceTime(0),
                // start immediately
                startWith(null),
                map(() => this._computeActive(descriptor)),
                filter(active => this.activeDescriptors[id] !== active),
              );
          }),
          map(active => setupField(active)),
          // make sure to kill this subscription when this fieldDescriptor is unregistered
          takeUntil(this.registeredDescriptors$.pipe(filter(fields => !fields[id]))),
        )
        .subscribe(active => {
          // extracting the value from the active descriptor is critically important
          // otherwise we get stuck in loops of updating the field
          const { value, ...rest } = active;

          // update the active descriptor
          this._activeDescriptors$.next({ ...this.activeDescriptors, [id]: rest });

          // handle updates that may result in changes to a field (not a field descriptor)
          // field descriptors are combinations of UI elements and field properties
          // it's important to make sure that all conditions that update field properties
          // (default, disabled, value, validations) are shared amongst field descriptors
          // that access the same field - otherwise we're in for some nasty behavior
          const nextDefault = this._resolveOptionalRef(active.default);
          if (nextDefault !== this.defaults[field.name]) {
            this._defaults$.next({ ...this.defaults, [field.name]: nextDefault });
          }

          if (active.disabled !== this.disabled[field.name]) {
            this._updateDisableStatus(field.name, !!active.disabled);
          }

          const shouldUpdateValue = typeof value !== 'undefined' || (typeof active.default !== 'undefined' && this.values[field.name] === this._initialValueForField(active));
          const toValue = this._resolveOptionalRef(typeof value !== 'undefined' ? value : active.default);
          if (shouldUpdateValue) {
            if (!isEqual(toValue, this.values[field.name])) {
              // undoing conditionally set values is a tricky concept, we'll try this:
              // if a value was set (default or by "value") on a field conditionally
              // then if that condition becomes void, call a "restore" function
              // which will restore the last value that was on that field
              const existingRestore = this._restore.get(field.name);
              const existing = this.values[field.name];
              this.changeField(field.name, toValue);

              // calling changeField deletes a restore for that field
              // so make sure we set the restore AFTER we call changeField
              this._restore.set(field.name, () => existingRestore ? existingRestore() : this.changeField(field.name, existing));
            }
          } else {
            this._doRestore(field.name);
          }

        });

    }

    return this.subscribeToFieldDescriptorAndState(field);
  }

  public subscribeToFieldDescriptorAndState(field: Field, paths: string[] = []) {
    const id = this._fieldDescriptorIdentifier(field);
    if (!this._descriptorAndFieldStates[id]) {
      this._descriptorAndFieldStates[id] = this._setupDescriptorAndFieldState(field);
    }

    return this._subscribeToPartOfThing(this._descriptorAndFieldStates[id], paths);
  }

  public unregisterFieldDescriptor(field: Field) {
    // if there are no more field descriptors registered for the
    // name specified by this field, remove it from touched, errors, values, etc
    const id = this._fieldDescriptorIdentifier(field);
    if (this.registeredDescriptors[id]) {

      const nextRegistered = { ...this.registeredDescriptors };
      delete nextRegistered[id];

      const nextActive = { ...this.activeDescriptors };
      delete nextActive[id];

      this._registeredDescriptors$.next(nextRegistered);
      this._activeDescriptors$.next(nextActive);

      delete this._descriptorAndFieldStates[id];
      if (!this._descriptorsForProp('name', field.name).length) {
        this._removeField(field.name);
      }

    }
  }

  public matches(condition: Condition) {
    return this._subscribeToThings(this.validationSchema$, this.types$)
      .pipe(
        // compute the schemas first for performance
        map(() => createSchemas(condition.when, this.types, this.validationSchema)),
        // then subscribe to the fields
        switchMap(schemas => combineLatest(of(schemas), this._subscribeToValues(...conditionSubscriptions(condition)))),
        map(([schemas]) => matches({ how: condition.how, schemas }, { ...this.context, ...this.values })),
        distinctUntilChanged(),
      );
  }

  public subscribeToFields(names: string[], paths: string[] = []) {
    return combineLatest(...names.map(n => this.subscribeToField(n, paths)))
      .pipe(
        map(what => names.reduce((acc, name, idx) => ({ ...acc, [name]: what[idx] }), {})),
      );
  }

  public subscribeToField(name: string, paths: string[] = []): Observable<any> {
    if (!this._fieldStates[name]) {
      this._fieldStates[name] = this._setupFieldState(name);
    }
    return this._subscribeToPartOfThing(this._fieldStates[name], paths);
  }

  public subscribeToFieldDescriptors(fields: Field[], paths: string[] = []) {
    return combineLatest(...fields.map(f => this.subscribeToFieldDescriptor(f, paths)));
  }

  public subscribeToFieldDescriptor(field: Field, paths: string[] = []) {
    return this._subscribeToPartOfThing(
      this._subscribeToFieldDescriptor(field).pipe(filter(a => !!a)),
      paths,
    );
  }

  public clearContext(key?: string | string[]) {
    this._context$.next(
      Object.keys(this.context).reduce((acc, k) => !key || key.includes(k) ? acc : ({ ...acc, [k]: this.context[k] }), {}),
    );
  }

  public setContext(context: Values | string, value?: any) {
    if (typeof context === 'string') {
      this._context$.next({ ...this.context, [FormBuilder._makeContextKey(context)]: value });
    } else {
      this._context$.next(Object.keys(context).reduce((acc, key) => ({
        ...acc,
        [FormBuilder._makeContextKey(key)]: context[key],
      }), this.context));
    }
  }

  private _unmodify(modification: Modification) {
    const modificationMap = this._modifications$.value;
    return this.batch(() => modificationMap.delete(modification) && this._modifications$.next(modificationMap));
  }

  private _applyLookup(lookupId: string) {
    const mod = this._lookups[lookupId];
    if (!mod) { return; }
    return this.modify(mod, { where: { lookupId: { is: lookupId } } });
  }

  private _resolveOptionalRef(ref: Ref) {
    return !ref || !ref.ref ? ref : get(FormBuilder._isContextKey(ref.ref) ? this.context : this.values, ref.ref);
  }

  private _subscribeToContext(key: string) {
    return this._subscribeToThing(this.context$).pipe(
      map(ctx => FormBuilder._isContextKey(key) ? ctx[key] : ctx[FormBuilder._makeContextKey(key)]),
      distinctUntilChanged(isEqual),
    );
  }

  private _subscribeToValues(...keys: string[]) {
    return combineLatest(...keys.map(k => FormBuilder._isContextKey(k) ? this._subscribeToContext(k) : this.subscribeToField(k, ['value'])));
  }

  public fieldsInErrorState(fields: Field[]) {
    return this._checkFields(fields, this.fieldInErrorState.bind(this));
  }

  public fieldInErrorState(field: Field) {
    const path = 'descriptor.showErrors';
    return this.subscribeToFieldDescriptorAndState(field, [path])
      .pipe(map(a => a[path]), distinctUntilChanged());
  }

  public fieldsRequired(fields: Field[]) {
    return this._checkFields(fields, this.fieldRequired.bind(this));
  }

  public fieldRequired(field: Field) {
    return this.subscribeToFieldDescriptor(field, ['required']).pipe(
      map(({ required }) => required),
    );
  }

  public changeField(name: string, val: any) {
    const fields = this._fieldsForName(name);

    // happens when descriptor has already been unregistered - noop
    if (!fields.length) {
      return;
    }

    this._modified.add(name);
    if (!isEqual(this._normalizedFieldValue(name, val), this.values[name])) {
      // delete any restore that may exist for this field
      // if the user, or something, has changed a field
      // we can assume that any restore function that previously
      // existed is no longer relevant
      // use case: change to field A causes a conditional update to field B
      // when user modifies the value of field A, we will not "restore"
      // the change to field B caused by the original conditional update
      // as the value in field B is now user-defined
      this._restore.delete(name);
      this._values$.next({ ...this.values, [name]: val });
    }
  }

  private _setupFieldState(name: string): Observable<FieldState> {
    const toName = map(a => a[name]);
    return this._subscribeToThings(
      this.values$.pipe(toName, distinctUntilChanged(isEqual)),
      this.errors$.pipe(toName, distinctUntilChanged(isEqual)),
      this.touched$.pipe(toName, distinctUntilChanged()),
      this.initialValues$.pipe(map(() => this._transformedInitialValues[name]), distinctUntilChanged(isEqual)),
      this.disabled$.pipe(toName, distinctUntilChanged()),
      this.defaults$.pipe(toName, distinctUntilChanged(isEqual)),
    )
      .pipe(
        map(([value, errors, touched, initialValue, disabled, def]) => ({
          disabled,
          initialValue,
          errors,
          touched,
          default: def,
          valid: isEmpty(errors),
          value: this._modified.has(name) ? value : initialValue,
        })),
        map(({ value, initialValue, default: def, ...rest }) => ({
          dirty: (this._modified.has(name) && !isEqual(value, initialValue) && !isEqual(value, def)),
          value,
          initialValue,
          default: def,
          ...rest,
        })),
        map(({ valid, touched, dirty, ...rest }) => ({
          ...rest,
          valid,
          touched,
          dirty,
          pristine: !dirty,
          invalid: !valid,
          untouched: !touched,
        })),
        distinctUntilChanged(isEqual),
        map(a => ({
          ...a,
          onChange: (what: any) => !this.disabled[name] && this.changeField(name, what),
          onTouched: (what: boolean) => this._onTouchField(name, what),
        })),
        shareReplay({ refCount: true, bufferSize: 1 }),
      );
  }

  private _onTouchField(name: string, touched: boolean) {
    this._touched$.next({ ...this.touched, [name]: touched });
  }

  private _doRestore(key: any) {
    if (this._restore.has(key)) {
      this._restore.get(key)();
      this._restore.delete(key);
    }
  }

  private _setupDescriptorAndFieldState(field: Field) {
    return combineLatest(
      this._subscribeToFieldDescriptor(field).pipe(filter(a => !!a)),
      this.subscribeToField(field.name),
      this._subscribeToThing(this.submitCount$),
    ).pipe(
      map(([descriptor, state, submitCount]) => ({
        state,
        descriptor: {
          ...descriptor,
          showErrors: showErrors(
            descriptor,
            !isEmpty(state.errors),
            state.touched,
            state.dirty,
            submitCount > 0,
          ),
        },
      })),
      shareReplay({ refCount: true, bufferSize: 1 }),
    );
  }

  private _subscribeToPartOfThing(thing$: Observable<any>, paths: string[] = []) {
    return !paths.length ? thing$ : thing$
      .pipe(
        filter(a => !!a),
        map(a => !paths.length ? a : paths.reduce((acc, name, idx) => ({
          ...acc,
          [name]: get(a, paths[idx]),
        }), {})),
        distinctUntilChanged(isEqual),
      );
  }

  private _checkFields(fields: Field[], method: (field: Field) => Observable<boolean>, how = 'some'): Observable<boolean> {
    return combineLatest(...fields.map(f => method(f)))
      .pipe(
        map(what => what[how]((w: boolean) => w)),
        distinctUntilChanged(),
      );
  }

  private _subscribeToFieldDescriptor(field: Field) {
    return this._subscribeToThing<FieldDescriptorMap>(this.activeDescriptors$)
      .pipe(
        map(a => a[this._fieldDescriptorIdentifier(field)]),
        distinctUntilChanged(),
      );
  }

  private _subscribeToThing<T>(what$: Observable<T>) {
    return this._subscribeToThings(what$)
      .pipe(map(([w]) => w));
  }

  // prevents observable emissions during batch processes
  private _subscribeToThings(...args: Array<Observable<any>>) {
    return this._batching$.pipe(
      filter(b => !b),
      switchMap(() => combineLatest(...args)),
      filter(() => !this._batching$.value),
    );
  }

  private _fieldDescriptorIdentifier(field: Field) {
    return field.id || field.name;
  }

  private _initialValueForField(field: Field) {
    if (typeof this._transformedInitialValues[field.name] === 'undefined') {
      this._transformedInitialValues[field.name] = defaultValueForField(field, from(this.initialValues, { field })[field.name]);
    }

    return this._transformedInitialValues[field.name];

  }

  private _removeField(name: string) {
    this.batch(() => {
      [
        this._touched$,
        this._values$,
        this._types$,
        this._fieldErrors$,
        this._disabled$,
        this._defaults$,
        this._validating$,
        this._initialValues$
      ].forEach(w$ => {
        const next = { ...w$.value };
        delete next[name];
        w$.next(next);
      });

      this._modified.delete(name);

      delete this._transformedInitialValues[name];
      delete this._fieldStates[name];
    });
  }

  private _fieldsForName(name: string) {
    return this._descriptorsForProp('name', name);
  }

  private _descriptorsForProp(propName: string, propValue: string): Field[] {
    return Object.keys(this.registeredDescriptors)
      .filter(key => isEqual(this.registeredDescriptors[key][propName], propValue))
      .map(k => this.registeredDescriptors[k]);
  }

  private _computeActive(field: Field) {
    return activeDescriptor(
      field,
      { ...this.context, ...this.values },
      this.types,
      this.validationSchema,
      this.activeDescriptors[field.id],
    );
  }

  private _normalizedFieldValue(fieldName: string, val: any) {
    const fields = this._fieldsForName(fieldName);
    const field = this.activeDescriptors[fields[0].id || fields[0].name];
    return field ? field.normalizer(val) : val;
  }


  private _modificationsForField(field: Field) {
    return [...this._modifications$.value.entries()].reduce((acc, [mod, { where }]) => {
      return !where ? ({ ...acc, ...mod }) : matches({ schemas: createSchemas(where), how: 'some' }, field) ? ({ ...acc, ...mod }) : acc;
    }, {});
  }

  private _out(values: Values) {

    return to(Object.keys(values).reduce((acc, fieldName) => ({
      ...acc,
      [fieldName]: this._normalizedFieldValue(fieldName, values[fieldName])
    }), {}), this.activeDescriptors);
  }

  private _updateDisableStatus(name: string, disabled: boolean) {
    this._disabled$.next({ ...this.disabled, [name]: disabled });
  }

}
