export interface FieldState {
  initialValue: any;
  errors: any;
  touched: boolean;
  untouched: boolean;
  valid: boolean;
  value: any;
  dirty: boolean;
  pristine: boolean;
  onChange: (value: any) => void;
  onTouched: (touched: boolean) => void;
}
