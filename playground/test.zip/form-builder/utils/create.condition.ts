import { FieldCondition, FieldValidator, ConditionHow, FormCondition, Condition } from '../interfaces';

const createCondition = (
  fields: string[],
  fieldsValidator: FieldValidator,
  how: ConditionHow = ConditionHow.SOME
): Condition  => ({
  when: fields.map(f => ({[f]: fieldsValidator})),
  how,
});

export const createFieldCondition = (
  fields: string[],
  fieldsValidator: FieldValidator,
  then: FieldCondition['then'],
  how: ConditionHow = ConditionHow.SOME,
  otherwise: FieldCondition['otherwise'] = {}
) => ({...createCondition(fields, fieldsValidator, how), then, otherwise, });

export const createFormCondition = (
  fields: string[],
  fieldsValidator: FieldValidator,
  then: FormCondition['then'],
  how: ConditionHow = ConditionHow.SOME,
  otherwise: FormCondition['otherwise'] = {}
) => ({...createCondition(fields, fieldsValidator, how), then, otherwise, });
