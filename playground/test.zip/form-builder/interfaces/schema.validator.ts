import { FieldValidator } from './field.validator';

export interface SchemaValidator {
  [key: string]: FieldValidator;
}
