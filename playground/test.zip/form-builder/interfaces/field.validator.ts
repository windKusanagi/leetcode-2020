import { ValidatorType } from './validator.type';
import { Ref } from './ref';

export type Type = ValidatorType[] | boolean | string | Ref;

export interface ExpandedValidator {
  value: Type;
  message?: string;
  schema?: any;
}


export interface FieldValidator {
  [key: string]: any;
}
