export interface Ref {
  ref: string;
}
