import { Field } from '../interfaces';
import { createTransformer } from './transform';
import { createMask } from './mask';
import { fieldOptions, compareWith } from './select.options';
import { FieldType } from '../interfaces';
import { FieldCastTransformType } from '../interfaces/transform';

const castForField = (field: Field): any => {
  switch (field.type) {
    case FieldType.NUMBER:
      return { cast: FieldCastTransformType.NUMBER };
    default:
      return null;
  }
};

export const normalizerForField = (field: Field) => createTransformer([castForField(field)].concat(field.normalize).filter(t => !!t));

export const setupField = (field: Field) => ({
    ...field,
    options: field.lookupId && !field.options ? undefined : fieldOptions(field),
    required: field.validations && field.validations.required,
    transformer: createTransformer(field.transform),
    normalizer: normalizerForField(field),
    mask: createMask(field.mask),
    compareWith: compareWith({compare: field.compare})
});
