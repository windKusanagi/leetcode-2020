import { Field } from '../interfaces';
import { getter } from 'property-expr';
import { isEqual, get } from 'lodash';

// convert a select options properties into labels and values
const getCompare = (compare: string, opt: any) => compare ? get(opt, compare, opt) : opt;
export const compareWith = ({ compare }: { compare: string }) => (o1: any, o2: any) => isEqual(getCompare(compare, o1), getCompare(compare, o2));

export const fieldOptions = (field: Field) =>
  (field.options || []).map((o: any) => {
    const display = field.lookupId ? 'key' : field.display;
    const accessor = field.lookupId ? 'key' : field.optionAccessor;
    const displayLocale = field.hasOwnProperty('displayLocale') ? field.displayLocale : field.lookupId;
    const rawLabel = display ? getter(display)(o) : o.hasOwnProperty('label') ? o.label : o;
    const value = accessor ? getter(accessor)(o) : o.hasOwnProperty('value') ? o.value : o;
    const label = displayLocale ? `${displayLocale}_${rawLabel}` : rawLabel;
    return {
      ...o,
      label,
      value,
    };
  }).filter(({ value }) => !(field.exclude || []).includes(value));
