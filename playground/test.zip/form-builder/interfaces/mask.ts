export type FieldMask = any;

export enum MaskType {
  POSTAL = 'postal',
  PHONE = 'phone'
}
