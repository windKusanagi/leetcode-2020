export interface SchemaValidationError {
  locale_id: string;
  value: {
    message?: string;
    params: object;
  };
}

export interface SchemaValidationErrors {
  [key: string]: SchemaValidationError;
}
