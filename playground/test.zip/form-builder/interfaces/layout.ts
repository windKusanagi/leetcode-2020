export interface VerboseFlexGrid {
  cols?: 'auto' | number;
  grow?: number;
  shrink?: number;
  spacing?: number;
}

export type FlexGrid = VerboseFlexGrid | number | 'auto';

export interface GridLayout {
  xs?: FlexGrid;
  sm?: FlexGrid;
  md?: FlexGrid;
  lg?: FlexGrid;
  xl?: FlexGrid;
}

export interface FieldGridLayout extends GridLayout {
  container?: FieldGridLayout;
}
