import {
  FieldDescriptorMap,
  Field,
  FieldType,
  SchemaValidationErrors,
  SchemaType,
} from '../interfaces';
import * as validationSchema from '@sti/validation-schema';
import { Schema, ValidationError, object } from 'yup';
import { Values } from '../interfaces/values';

const { createSchema } = validationSchema;

export const schemaForType = (type: FieldType): SchemaType => {
  switch (type) {
    case FieldType.NUMBER:
      return SchemaType.NUMBER;
    case FieldType.DATE:
      return SchemaType.DATE;
    default:
      return SchemaType.STRING;
  }
};

export const fieldSchemaTypes = (fields: Field[]) =>
  fields.reduce(
    (acc, { name, type }) => ({
      ...acc,
      [name]: schemaForType(type),
    }),
    {}
  );

export const createFormValidationSchema = (fields: Field[]): Schema<any> =>
  createSchema(
    fields.reduce(
      (acc, { name, validations }) => ({
        ...acc,
        [name]: validations || {},
      }),
      {}
    ),
    fieldSchemaTypes(fields)
  );

export const validate = async (
  value: any,
  schema: Schema<any>
): Promise<SchemaValidationErrors | null> => {
  try {
    await schema.validate(value, { abortEarly: false });
    return {};
  } catch (err) {
    return (<ValidationError>err).inner.reduce(
      (acc, { path, message, type, params }) => ({
        ...acc,
        [path]: {
          ...(acc[path] || {}),
          [type]: { message, params, type },
        },
      }),
      {}
    );
  }
};

export const validateField = async (fieldName: string, schema: any, values: Values) => {
  const against = schema.fields[fieldName];
  if (!against) return undefined;
  const errors = await validate(values, object({[fieldName]: against}));
  return errors[fieldName];
};

export const localizedValidationError = (
  { params, type, message },
  fields: FieldDescriptorMap,
  localizeFn: (label: string, params?: any) => string
): string => {
  // min and max errors need an extra prefix of the field type as
  // the default localized error message will differ depending if the field
  // is a date, number, or string
  const errorType = ['min', 'max'].includes(type)
    ? `${fields[params.path].type || 'text'}_${type}`
    : type;
  const localize = (name: string) => localizeFn(fields[name].label || 'form_field_no_label');
  return localizeFn(
    message || `form_error_${type === 'application' ? params.type : errorType}`,
    {
      ...params,
      label: localize(params.path),
      field: params.field ? localize(params.field) : undefined,
      compare: params.compare,
      options: params.options
        ? params.options.map(o => localize(o.ref || o)).join(', ')
        : undefined,
    }
  );
};
