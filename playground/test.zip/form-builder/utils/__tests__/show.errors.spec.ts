import { showErrors } from '../show.errors';
import { FormFieldErrors } from '../../interfaces';

const TOUCHED_BEHAVIOR = { when: FormFieldErrors.TOUCHED };
const DIRTY_BEHAVIOR = { when: FormFieldErrors.DIRTY };
const NONE_BEHAVIOR = { when: FormFieldErrors.NONE };
const SUBMITTED_BEHAVIOR = { submitted: true };
const NOT_SUBMITTED_BEHAVIOR = { submitted: false };

const ALL_BEHAVIORS = [TOUCHED_BEHAVIOR, DIRTY_BEHAVIOR, NONE_BEHAVIOR].reduce(
  (acc, b) =>
    acc.concat(
      { behavior: { ...b, ...SUBMITTED_BEHAVIOR } },
      { behavior: { ...b, ...NOT_SUBMITTED_BEHAVIOR } }
    ),
  []
);

// http://zacg.github.io/blog/2013/08/02/binary-combinations-in-javascript/
const binaryCombos = n => {
  const result = [];
  for (let y = 0; y < Math.pow(2, n); y++) {
    const combo = [];
    for (let x = 0; x < n; x++) {
      // shift bit and and it with 1
      // tslint:disable-next-line
      (y >> x) & 1 ? combo.push(true) : combo.push(false);
    }
    result.push(combo);
  }
  return result;
};

describe('show errors', () => {
  it('should never show errors if the field is disabled', () =>
    ALL_BEHAVIORS.forEach(b =>
      binaryCombos(4).forEach(p => {
        expect(showErrors({ ...b, disabled: true }, p[0], p[1], p[2], p[3])).toBe(false);
      })
    ));

  it('should never show errors if the field is readOnly', () =>
    ALL_BEHAVIORS.forEach(b =>
      binaryCombos(4).forEach(p =>
        expect(showErrors({ ...b, readOnly: true }, p[0], p[1], p[2], p[3])).toBe(false)
      )
    ));

  it('should never show errors if there are none', () =>
    ALL_BEHAVIORS.forEach(b =>
      binaryCombos(3).forEach(p =>
        expect(showErrors(b, false, p[0], p[1], p[2])).toBe(false)
      )
    ));

  it('should never show errors where behavior is none', () =>
    ALL_BEHAVIORS.filter(
      ({ behavior }) => behavior === FormFieldErrors.NONE
    ).forEach(b =>
      binaryCombos(4).forEach(p => expect(showErrors(b, p[0], p[1], p[2], p[3])).toBe(false))
    ));

  it('should show errors when touched and the behavior is touched', () =>
    ALL_BEHAVIORS.filter(
      ({ behavior }) => behavior.when === FormFieldErrors.TOUCHED
    ).forEach(b =>
      binaryCombos(2).forEach(p =>
        expect(showErrors(b, true, true, p[0], p[1])).toBe(true)
      )
    ));

  it('should show errors when dirty and the behavior is dirty', () =>
    ALL_BEHAVIORS.filter(
      ({ behavior }) => behavior === FormFieldErrors.DIRTY
    ).forEach(b => {
      expect(showErrors(b, true, false, true, false));
      expect(showErrors(b, true, false, true, true));
      expect(showErrors(b, true, true, true, false));
      expect(showErrors(b, true, true, true, true));
    }));

  it('should show errors when submitted regardless of the behavior', () =>
    ALL_BEHAVIORS.filter(({ behavior }) => behavior.submitted).forEach(b => {
      binaryCombos(2).forEach(p => {
        expect(showErrors(b, true, p[0], p[1], true));
      });
    }));
});
