import { fieldOptions, compareWith } from '../select.options';
import { FieldType } from '../../interfaces';

describe('select options', () => {

  const fieldFixture = {
    'name': 'province',
    'type': FieldType.SELECT,
    'label': 'province',
    'path': 'healthCareProfessional.person.contactInfo.firstName',
    'validations': {
      'max': 40
    },
  };

  const accessorFixture = {
    ...fieldFixture,
    display: 'nested.someProp',
    optionAccessor: 'nested.someVal',
    options: [
      {
        nested: {
          someProp: 'displayA',
          someVal: 'valueA',
        },
      },
      {
        nested: {
          someProp: 'displayB',
          someVal: 'valueB',
        },
      },
      {
        nested: {
          someProp: 'displayC',
          someVal: 'valueC',
        },
      },
    ],
  };

  const labelFixture = {
    ...fieldFixture,
    options: [
      {
        label: 'displayA',
        value: 'valueA',
      },
      {
        label: 'displayB',
        value: 'valueB',
      },
    ],
  };

  const rawFixture = {
    ...fieldFixture,
    options: ['A', 'B', 'C'],
  };

  it('should obey display and optionAccessor', () => {
    const o = fieldOptions(accessorFixture);
    expect(o[0].label).toBe('displayA');
    expect(o[0].value).toBe('valueA');
  });

  it('should obey display without optionAccessor', () => {
    const o = fieldOptions({ ...accessorFixture, optionAccessor: undefined });
    expect(o[0].label).toBe('displayA');
    expect(o[0].value).toBe(accessorFixture.options[0]);
  });

  it('should obey label and value', () => {
    const o = fieldOptions(labelFixture);
    expect(o[1].label).toBe(labelFixture.options[1].label);
    expect(o[1].value).toBe(labelFixture.options[1].value);
  });

  it('should use a primitive value as a label and a value', () => {
    const o = fieldOptions(rawFixture);
    expect(o[2].label).toBe(rawFixture.options[2]);
    expect(o[2].value).toBe(rawFixture.options[2]);
  });

  it('should localize when displayLocale is present', () => {
    const o = fieldOptions({ ...accessorFixture, displayLocale: 'prefix' });
    expect(o[0].label).toBe('prefix_displayA');
  });

  it('should provide a custom comparator', () => {
    const compare = 'key';
    const options = [
      {
        'label': 'Not eligible for public coverage',
        'value': {
          'key': 'NOT_ELIGIBLE_FOR_PUBLIC_COVERAGE',
          'value': 'Not eligible for public coverage'
        }
      },
      {
        'label': 'Bridge to public coverage',
        'value': {
          'key': 'BRIDGE_TO_PUBLIC_COVERAGE',
          'value': 'Bridge to public coverage'
        }
      }
    ];

    const value = {
      'key': 'BRIDGE_TO_PUBLIC_COVERAGE',
      'value': 'Bridge to public coverage'
    };

    expect(compareWith({compare})(options[0].value, value)).toBe(false);
    expect(compareWith({compare})(options[1].value, value)).toBe(true);
  });
});
