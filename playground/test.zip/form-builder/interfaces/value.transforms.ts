export enum ValueTransformPathType {
  ARRAY = 'array'
}

interface PlainObject {
  [key: string]: any;
}
export interface ValueTransform extends PlainObject {
  path?: string;
  name?: string;
  accessor?: string;
  value?: any;
  default?: any;
  metaValue?: any;
  disabled?: boolean;
  fieldPathType?: ValueTransformPathType;
}

export interface ValueTransforms {
  [key: string]: ValueTransform;
}
