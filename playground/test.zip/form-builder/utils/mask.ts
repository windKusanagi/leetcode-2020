import { MaskType } from '../interfaces';

const MaskTypes = {
  // enum: MaskedEnum,
  // range: MaskedRange,
  date: Date,
  number: Number,
  [MaskType.POSTAL]: 'a0a0a0',
  [MaskType.PHONE]: `(000)-000-0000`,
};

const maskType = mask => MaskTypes[mask] || mask;

const convertBlocks = blocks => Object.keys(blocks).reduce((acc, key) => {
  const { mask, ...rest } = blocks[key];
  return {
    ...acc,
    [key]: {
      mask: maskType(mask),
      ...rest
    }
  };
}, {});

export const DEFAULT_MASK = /^.*$/;

// convert a configuration mask definition to an IMask definition
export const createMask = mask => ({
  mask: (Array.isArray(mask) ? mask : [mask || DEFAULT_MASK]).map(m => {
    if (typeof m === 'string' || m instanceof RegExp) {
      return { mask: maskType(m) };
    }

    return {
      ...m,
      mask: maskType(m.mask),
      blocks: m.blocks ? convertBlocks(m.blocks) : undefined,
    };
  }),
});
