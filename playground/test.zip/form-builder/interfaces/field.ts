import { Condition, When } from './condition';
import { FieldTransform } from './transform';
import { FieldMask } from './mask';
import { MatFormFieldAppearance, FloatLabelType } from '@angular/material';
import { FieldValidator } from './field.validator';
import { ValueTransform } from './value.transforms';
import { VerboseFlexGrid } from './layout';

export enum FormFieldErrors {
  TOUCHED = 'touched',
  DIRTY = 'dirty',
  NONE = 'none',
  ALWAYS = 'always'
}

export interface FormErrorProperties {
  when: FormFieldErrors;
  submitted?: boolean;
  numErrors?: number;
}

export interface FieldTypeMap {
  [key: string]: keyof FieldType;
}

// TO DO:
// specify a "custom" type - specifies it's own fields configuration to dynamically create a custom sub-control
// specify a "formFieldType" - "list" (+ options) that allows you to turn any control into a list of controls - think medication history
export enum FieldType {
  TEXT = 'text',
  TEXTAREA = 'textarea',
  DATE = 'date',
  DATE_DROPDOWN = 'date_dropdown',
  SELECT = 'select',
  AUTOCOMPLETE = 'autocomplete',
  MULTISELECT = 'multiselect',
  EMAIL = 'email',
  NUMBER = 'number',
  PASSWORD = 'password',
  PHONE = 'tel',
  CHECKBOX = 'checkbox',
  RADIOGROUP = 'radiogroup',
  RADIOBUTTON = 'radiobutton',
  FILE = 'dropfile'
}


export type Modification = Partial<Field>;

export interface FieldCondition extends Condition {
  then?: Modification;
  otherwise?: Modification;
}

export interface Modifier { [key: string]: Modification; }

export interface GlobalFormCondition extends Condition {
  where?: When;
  then?: Modification;
  otherwise?: Modification;
}

export interface FormModifier extends Modification {
  where?: When;
}

export interface FormCondition extends Condition {
  then?: Modifier;
  otherwise?: Modifier;
}

export interface OptionIcon {
  url?: string;
  material?: string;
  styles?: object;
}

export interface VerboseOption {
  label: string;
  value: any;
  icon?: OptionIcon;
}

export interface FieldAppearance {
  style?: MatFormFieldAppearance;
  floatLabel?: FloatLabelType;
}

export interface FieldDescriptorMap {
  [key: string]: Field;
}

export type Option = string | VerboseOption | object;

export enum FieldLayout {
  HORIZONTAL = 'horizontal',
  VERTICAL = 'vertical'
}

export interface Field extends ValueTransform {
  id?: string; // for when we have multiple fields that need access to the same control (via name) in the same form section
  label: string;
  type: FieldType;
  spacing?: VerboseFlexGrid['spacing'];
  value?: any;
  name: string;
  style?: string;
  default?: any;
  disabled?: boolean;
  readOnly?: boolean;
  hint?: string;
  conditionKey?: string; // used internally for performance
  placeholder?: string;
  hidden?: boolean;
  exclude?: string[];
  modes?: string[];
  validations?: FieldValidator;
  fieldLayout?: FieldLayout;
  conditions?: FieldCondition[];
  transform?: FieldTransform;
  normalize?: FieldTransform;
  mask?: FieldMask;
  appearance?: FieldAppearance;
  behavior?: FormErrorProperties;

  required?: boolean;
  transformer?: (...args: any[]) => void;
  normalizer?: (...args: any[]) => void;

  // checkbox field
  on?: any;
  off?: any;

  // date field
  startAt?: string;
  view?: 'month' | 'year' | 'multi-year';

  // option field
  emptyOption?: string;
  lookupId?: string;
  options?: Option[];
  display?: string; // path to display or function
  displayLocale?: string; // locale_id prefix
  optionAccessor?: string; // path of an option to select as a value
  compare?: string; // path of the option that should be compare to determine if it's selected

  // radio (NOT radiogroup)
  fieldValue?: any;

  // autocomplete field
  url?: string;
  urlMethod?: 'GET' | 'POST';
  urlParams?: any;
  debounce?: number;
  emptyText?: string;
  loadingText?: string;
  minCharacters?: number;
  autoselect?: boolean;
  filterAccessor?: string; // when query matches against a certain property - ignored when async
  sortAccessor?: string; // use to sort based on string
  sortOrder?: 'asc' | 'desc';
  dataAccessor?: string; // select a certain property from results fetched from server

  // attributes passed through to the native input element
  attributes?: { [key: string]: string }[];

  // dropfile field
  multiple?: boolean;
  showList?: boolean;
  noClick?: boolean;
  accept?: string[];

  // date input mask
  dateMask?: (string | RegExp)[];
}

